# Security Compliance Center

Generate BitLocker, Defender, firewall and local-admin audit reports.

## Usage
1. Extract this ZIP locally.
2. Open `index.html` in Edge or Chrome. Internet access is not required.
3. Configure fields and click Generate files.
4. Review the PowerShell code and download the generated files.
5. Test in a non-production environment before use.

## Security
- No telemetry, no remote APIs, no credentials requested, and no automatic command execution.
- The app is delivered privately via your existing authenticated Cloudflare R2 download endpoint.
- Generated scripts may require elevation or modules and should be code-reviewed.
- Do not publish the extracted HTML to public GitHub Pages if you want it restricted to Pro members.
