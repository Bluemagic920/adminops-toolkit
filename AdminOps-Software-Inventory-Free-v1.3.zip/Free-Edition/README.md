# AdminOps Software Inventory — Free Edition v1.3

Windows PowerShell 5.1, Windows 10/11. Extract ZIP and double-click `Start-GUI.cmd`. The GUI scans uninstall registry entries, filters by application name, and exports CSV.

**Read-only:** This package contains no uninstall engine, removal commands, or hidden Pro unlock switch. CSV exports may contain software inventory information; handle accordingly.

CLI export example: `powershell.exe -NoProfile -File .\Export-Inventory.ps1 -Path "$env:USERPROFILE\Desktop\inventory.csv"`

Inventory is based on registered uninstall entries. Some portable, Store, or per-user apps for other users may not appear.
