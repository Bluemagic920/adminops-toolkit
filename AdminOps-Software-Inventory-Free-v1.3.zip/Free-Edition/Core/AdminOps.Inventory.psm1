﻿#Requires -Version 5.1
Set-StrictMode -Version Latest
function Get-AdminOpsInventory {
    [CmdletBinding()]
    param()
    $paths = @(
      'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
      'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
      'Registry::HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach ($path in $paths) {
      foreach ($item in @(Get-ItemProperty -Path $path -ErrorAction SilentlyContinue)) {
        if ($null -eq $item) { continue }
        $nameProp = $item.PSObject.Properties['DisplayName']
        if ($null -eq $nameProp -or [string]::IsNullOrWhiteSpace([string]$nameProp.Value)) { continue }
        $systemProp = $item.PSObject.Properties['SystemComponent']
        if ($null -ne $systemProp -and $systemProp.Value -eq 1) { continue }
        $releaseProp = $item.PSObject.Properties['ReleaseType']
        if ($null -ne $releaseProp -and [string]$releaseProp.Value -in @('Update','Hotfix','Security Update')) { continue }
        $version = $item.PSObject.Properties['DisplayVersion']
        $publisher = $item.PSObject.Properties['Publisher']
        [pscustomobject]@{
          Name = [string]$nameProp.Value
          Version = if ($null -eq $version) { '' } else { [string]$version.Value }
          Publisher = if ($null -eq $publisher) { '' } else { [string]$publisher.Value }
        }
      }
    }
}
Export-ModuleMember -Function Get-AdminOpsInventory
