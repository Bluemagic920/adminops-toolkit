﻿#Requires -Version 5.1
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Import-Module (Join-Path $PSScriptRoot '..\Core\AdminOps.Inventory.psm1') -Force
[System.Windows.Forms.Application]::EnableVisualStyles()
$form = New-Object System.Windows.Forms.Form
$form.Text = 'AdminOps Software Inventory - Free'; $form.Width = 940; $form.Height = 610; $form.StartPosition = 'CenterScreen'
$search = New-Object System.Windows.Forms.TextBox
$search.SetBounds(16,16,610,28)
$refresh = New-Object System.Windows.Forms.Button
$refresh.Text = 'Refresh'; $refresh.SetBounds(640,14,110,32)
$export = New-Object System.Windows.Forms.Button
$export.Text = 'Export CSV'; $export.SetBounds(760,14,145,32)
$grid = New-Object System.Windows.Forms.DataGridView
$grid.SetBounds(16,60,890,420); $grid.ReadOnly = $true; $grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false; $grid.SelectionMode = 'FullRowSelect'; $grid.MultiSelect = $false
$grid.AutoSizeColumnsMode = 'Fill'; $grid.RowHeadersVisible = $false
$status = New-Object System.Windows.Forms.Label
$status.SetBounds(16,495,890,55); $status.Text = 'Read-only inventory. No uninstall capability.'
$form.Controls.AddRange(@($search,$refresh,$export,$grid,$status))
$script:apps = @()
function Update-Grid {
    try {
        $query = [string]$search.Text
        $view = @($script:apps | Where-Object { [string]::IsNullOrWhiteSpace($query) -or ([string]$_.Name).IndexOf($query,[StringComparison]::OrdinalIgnoreCase) -ge 0 })
        $table = New-Object System.Data.DataTable
        [void]$table.Columns.Add('Name',[string]); [void]$table.Columns.Add('Version',[string]); [void]$table.Columns.Add('Publisher',[string])
        foreach ($app in $view) { [void]$table.Rows.Add([string]$app.Name,[string]$app.Version,[string]$app.Publisher) }
        $grid.DataSource = $null; $grid.DataSource = $table; $grid.ClearSelection()
        $status.Text = "$($view.Count) applications shown (of $($script:apps.Count) detected). Read-only."
    } catch { $status.Text = "Display error: $($_.Exception.Message)"; [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Display error') | Out-Null }
}
function Refresh-Apps {
    try { $script:apps = @(Get-AdminOpsInventory | Sort-Object Name,Version); Update-Grid }
    catch { $status.Text = 'Scan failed: ' + $_.Exception.Message; [System.Windows.Forms.MessageBox]::Show($_.Exception.ToString(),'Scan failed') | Out-Null }
}
$refresh.Add_Click({ Refresh-Apps })
$search.Add_TextChanged({ Update-Grid })
$export.Add_Click({
    try {
        $dialog = New-Object System.Windows.Forms.SaveFileDialog
        $dialog.Filter = 'CSV files (*.csv)|*.csv'; $dialog.FileName = 'AdminOps-Software-Inventory.csv'
        if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $script:apps | Select-Object Name,Version,Publisher | Export-Csv -LiteralPath $dialog.FileName -NoTypeInformation -Encoding UTF8
            $status.Text = 'Inventory exported to: ' + $dialog.FileName
        }
    } catch { [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'Export failed') | Out-Null }
})
$form.Add_Shown({ Refresh-Apps })
[void]$form.ShowDialog()
