﻿#Requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory)][string]$Path)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'Core\AdminOps.Inventory.psm1') -Force
Get-AdminOpsInventory | Sort-Object Name,Version | Export-Csv -LiteralPath $Path -NoTypeInformation -Encoding UTF8
Write-Host "Exported inventory to $Path"
