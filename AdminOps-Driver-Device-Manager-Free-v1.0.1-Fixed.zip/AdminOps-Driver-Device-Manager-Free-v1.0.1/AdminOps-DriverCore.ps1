﻿Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
function Get-AdminOpsDeviceInventory {
    $drivers = @{}
    Get-CimInstance Win32_PnPSignedDriver -ErrorAction SilentlyContinue | ForEach-Object {
        if ($_.DeviceID -and -not $drivers.ContainsKey($_.DeviceID)) { $drivers[$_.DeviceID] = $_ }
    }
    @(Get-CimInstance Win32_PnPEntity | ForEach-Object {
        $d = $null
        if ($_.PNPDeviceID -and $drivers.ContainsKey($_.PNPDeviceID)) { $d = $drivers[$_.PNPDeviceID] }
        [pscustomobject]@{
            Name = $_.Name
            DeviceID = $_.PNPDeviceID
            Manufacturer = $_.Manufacturer
            Class = $_.PNPClass
            Status = $_.Status
            ProblemCode = $_.ConfigManagerErrorCode
            DriverProvider = if ($d) { $d.DriverProviderName } else { '' }
            DriverVersion = if ($d) { $d.DriverVersion } else { '' }
            DriverDate = if ($d) { $d.DriverDate } else { '' }
            InfName = if ($d) { $d.InfName } else { '' }
        }
    })
}
function Export-AdminOpsInventory {
    param([Parameter(Mandatory)]$Data,[Parameter(Mandatory)][string]$Path)
    @($Data) | Export-Csv -LiteralPath $Path -NoTypeInformation -Encoding UTF8
}
