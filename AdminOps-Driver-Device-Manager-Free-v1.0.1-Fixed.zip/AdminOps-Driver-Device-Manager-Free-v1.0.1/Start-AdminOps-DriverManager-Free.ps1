﻿# AdminOps Driver & Device Manager - Free v1.0
# Read-only device inventory and CSV export. Windows PowerShell 5.1.
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
. "$PSScriptRoot\AdminOps-DriverCore.ps1"
$form = New-Object Windows.Forms.Form
$form.Text = 'AdminOps Driver & Device Manager - Free v1.0'
$form.Width = 1100; $form.Height = 690; $form.StartPosition = 'CenterScreen'
$form.MinimumSize = New-Object Drawing.Size(760,450)
$top = New-Object Windows.Forms.FlowLayoutPanel
$top.Dock='Top'; $top.Height=46; $top.Padding=New-Object Windows.Forms.Padding(8)
$scan=New-Object Windows.Forms.Button; $scan.Text='Scan devices'; $scan.Width=125
$export=New-Object Windows.Forms.Button; $export.Text='Export CSV'; $export.Width=115
$search=New-Object Windows.Forms.TextBox; $search.Width=250
$label=New-Object Windows.Forms.Label; $label.Text='Search:'; $label.AutoSize=$true; $label.Padding=New-Object Windows.Forms.Padding(6,6,0,0)
$errors=New-Object Windows.Forms.CheckBox; $errors.Text='Errors only'; $errors.AutoSize=$true
$top.Controls.AddRange(@($scan,$export,$label,$search,$errors))
$grid=New-Object Windows.Forms.DataGridView
$grid.Dock='Fill';$grid.ReadOnly=$true;$grid.AllowUserToAddRows=$false;$grid.AutoSizeColumnsMode='DisplayedCells';$grid.SelectionMode='FullRowSelect'
$status=New-Object Windows.Forms.Label;$status.Dock='Bottom';$status.Height=28;$status.Text='Ready. Scan to load devices.'
$form.Controls.Add($grid);$form.Controls.Add($top);$form.Controls.Add($status)
$script:all=@();$script:shown=@()
function Update-Grid {
    $term=$search.Text
    $script:shown=@($script:all | Where-Object {
        (-not $errors.Checked -or $_.ProblemCode -ne 0) -and
        (-not $term -or $_.Name -like "*$term*" -or $_.DeviceID -like "*$term*" -or $_.Manufacturer -like "*$term*" -or $_.Class -like "*$term*")
    })
    $grid.DataSource=$null
    $list=New-Object System.Collections.ArrayList
    foreach ($entry in $script:shown) { [void]$list.Add($entry) }
    $grid.DataSource=$list
    $status.Text="Showing $($script:shown.Count) of $($script:all.Count) devices. Nonzero problem code indicates a reported device issue."
}
$scan.Add_Click({
    try { $status.Text='Scanning...';$form.Refresh();$script:all=@(Get-AdminOpsDeviceInventory);Update-Grid }
    catch { [Windows.Forms.MessageBox]::Show($_.Exception.Message,'Scan failed') | Out-Null }
})
$search.Add_TextChanged({Update-Grid})
$errors.Add_CheckedChanged({Update-Grid})
$export.Add_Click({
    if (-not $script:shown.Count) { [Windows.Forms.MessageBox]::Show('Scan first or clear the filter.','Nothing to export') | Out-Null;return }
    $dialog=New-Object Windows.Forms.SaveFileDialog;$dialog.Filter='CSV files (*.csv)|*.csv';$dialog.FileName='AdminOps-Device-Inventory.csv'
    if ($dialog.ShowDialog() -eq 'OK') {try { Export-AdminOpsInventory -Data $script:shown -Path $dialog.FileName;[Windows.Forms.MessageBox]::Show('CSV saved.','Export complete') | Out-Null }catch {[Windows.Forms.MessageBox]::Show($_.Exception.Message,'Export failed') | Out-Null}}
})
[void]$form.ShowDialog()
