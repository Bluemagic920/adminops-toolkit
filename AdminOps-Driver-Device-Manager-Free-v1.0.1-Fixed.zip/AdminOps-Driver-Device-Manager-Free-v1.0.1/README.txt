AdminOps Driver & Device Manager Free v1.0

Requirements: Windows 10/11, Windows PowerShell 5.1, Windows Forms.
Run: Open Windows PowerShell, cd to the extracted folder, then run .\Start-AdminOps-DriverManager-Free.ps1
If script execution is restricted, use an approved organizational execution policy; do not weaken managed policies.
Free features: scan Plug and Play devices, inspect driver metadata, filter device errors, search, export CSV.
Read-only: no device configuration changes.
A problem code other than 0 suggests a device problem but does not establish its cause.
